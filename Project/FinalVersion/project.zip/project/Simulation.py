# COMP 9334 19s1 Project: Fog/Cloud Computing
# Author: Wenxun Peng
# Student ID: z5195349
# Date: 7/4/2019

import threading
# Simulating a PS server
# maintain the list of jobs


# Attributes of jobs, it includes all the record we need
class Jobs:
    def __init__(self, index, arvTime, resTime):
        self.index = index
        self.arvTime = arvTime
        self.resTime = resTime
        self.responseTime = 0
        self.fogDeTime = 0
        self.networkDeTime = 0
        self.cloudDeTime = 0
        self.finish = 0

    # This is a flag that tells the system to finish the work
    def finish_time(self):
        self.finish = 1

    def modify_res_time(self, time):
        self.resTime = time

    def modify_response_time(self, time):
        self.responseTime = time

    def modify_fog_time(self, time):
        self.fogDeTime = time

    def modify_network_time(self, time):
        self.networkDeTime = time

    def modify_cloud_time(self, time):
        self.cloudDeTime = time


'''
# Example 1
# arrival_time_list = [1, 2, 3, 5, 15]
# server_time_list = [2.1, 3.3, 1.1, 0.5, 1.7]
# Example 2
arrival_time_list = [1.1, 6.2, 7.4, 8.3, 9.1, 10.1]
server_time_list = [4.1, 5.2, 1.3, 2.0, 3.2, 4.1]
network_latency = [1.5, 1.3, 0, 0, 1.6, 1.8]
fogTimeLimit = 2
fogTimeToCloudTime = 0.6
# Example 3
arrival_time_list = [1, 2, 4, 5, 6]
server_time_list = [3.7, 5.1, 1.3, 2.4, 4.5]
network_latency = [1.5, 1.4, 0, 0, 1.6]
fogTimeLimit = 2.5
fogTimeToCloudTime = 0.7
time_end = 100
'''
arrival_time_list = []
server_time_list = []
network_latency = []
server_in_fog = []
server_in_cloud = []
fogTimeLimit = 0
fogTimeToCloudTime = 0
time_end = float('inf')
list_in_network = []
list_in_cloud = []
record_list = []


# update the service time when arrival/departure
def update_service_time(current_time, last_time, jobs_list):
    processing_time = current_time - last_time
    nb_of_jobs = len(jobs_list)
    for i in range(nb_of_jobs):
        if jobs_list[i].arvTime != current_time:
            # residual service time
            jobs_list[i].modify_res_time(jobs_list[i].resTime - processing_time/nb_of_jobs)


# update the next departure time
def update_next_departure_time(current_time, jobs_list):
    nb_of_jobs = len(jobs_list)
    min_next_departure_time = float('inf')
    min_index = 0
    for i in range(nb_of_jobs):
        next_departure_time = current_time + (jobs_list[i].resTime * nb_of_jobs)
        if next_departure_time < min_next_departure_time:
            min_next_departure_time = next_departure_time
            min_index = jobs_list[i].index
    return min_next_departure_time, min_index


# delete the job and return
def del_job(index, job_list):
    nb_of_jobs = len(job_list)
    for i in range(nb_of_jobs):
        if job_list[i].index == index:
            job_delete = job_list.pop(i)
            return job_delete


class ProcessorSharingInFog(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        global time_end
        global arrival_time_list
        global server_in_fog
        global server_in_cloud
        global list_in_network
        global network_latency
        global record_list
        next_departure_time = float('inf')  # initial value is infinite
        if arrival_time_list:
            total_jobs = len(arrival_time_list)
            next_arrival_time = arrival_time_list[0]   # initial value is the first arrival
        else:
            print("Arrival list is empty!")
            return

        processing_jobs = 0
        leaving_jobs = 0
        job_list = []
        last_time = 0
        index = 0
        print("Processor sharing in fog...\n")
        while True:
            # next event is arrival and has no less than 1 job in the sequence
            if next_arrival_time < next_departure_time and processing_jobs < total_jobs:
                # Master clock equal to upcoming arrival time
                master_clock = next_arrival_time
                if master_clock >= time_end:
                    # end simulation
                    job_finish = Jobs(0, 0, 0)
                    # set the finish flag to 1 and send to the network
                    job_finish.finish_time()
                    list_in_network.append(job_finish)
                    break
                # update the residual service time of each job when one job arrival
                update_service_time(master_clock, last_time, job_list)
                # add jobs to job list, since the new jobs are not served,
                # the residual service time is initial service time
                jobs_object = Jobs(processing_jobs, master_clock, server_in_fog[processing_jobs])
                job_list.append(jobs_object)
                # record the job to output finally
                record_list.append(jobs_object)
                # update the next departure time by comparing the least value
                next_departure_time, index = update_next_departure_time(master_clock, job_list)
                last_time = master_clock
                processing_jobs += 1
                # there is no job and we just loop the departure part
                if processing_jobs >= total_jobs:
                    continue
                next_arrival_time = arrival_time_list[processing_jobs]
            else:                                          # next event is departure or just has departure event
                # Master clock equal to upcoming departure time
                master_clock = next_departure_time
                if master_clock >= time_end:
                    job_finish = Jobs(0, 0, 0)
                    job_finish.finish_time()
                    list_in_network.append(job_finish)
                    break
                # update the residual service time of each job when one job departure
                update_service_time(master_clock, last_time, job_list)

                # delete the finished job
                job_departure = del_job(index, job_list)
                # just departure fog or departure fog to network
                if network_latency[job_departure.index] == 0 and server_in_cloud[job_departure.index] == 0:
                    job_departure.modify_response_time(master_clock - job_departure.arvTime)
                    job_departure.modify_fog_time(master_clock)

                else:
                    job_departure.modify_fog_time(master_clock)
                    server_residual_time = server_in_cloud[job_departure.index]
                    job_departure.modify_res_time(server_residual_time)
                    list_in_network.append(job_departure)

                # update the next departure time by comparing the least value
                next_departure_time, index = update_next_departure_time(master_clock, job_list)
                last_time = master_clock
                leaving_jobs += 1
                # if the jobs queue is vacant, then set the next departure time equal to infinite
                if len(job_list) == 0:
                    next_departure_time = float('inf')
                # all jobs are leaving, then break
                if leaving_jobs >= total_jobs:
                    job_finish = Jobs(0, 0, 0)
                    job_finish.finish_time()
                    list_in_network.append(job_finish)
                    break


class NetworkLatency(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        global time_end
        global list_in_network
        global list_in_cloud
        global network_latency
        departure_time_list = []
        next_departure_time = float('inf')
        network_latency_jobs = []
        print("Network latency...\n")
        while True:
            # waiting for the jobs arrival
            if list_in_network:
                network_processor = list_in_network.pop(0)
                master_clock = network_processor.fogDeTime
                if master_clock >= time_end or network_processor.finish == 1:
                    # some jobs don't departure so clear the jobs list whose jobs are sent by time end
                    while network_latency_jobs and next_departure_time < time_end:
                        for j in range(len(network_latency_jobs)):
                            if network_latency_jobs[j].networkDeTime == next_departure_time:
                                list_in_cloud.append(network_latency_jobs[j])
                                del network_latency_jobs[j]
                                del departure_time_list[j]
                                break
                        if departure_time_list:
                            next_departure_time = min(departure_time_list)
                        else:
                            break
                    job_finish = Jobs(0, 0, 0)
                    job_finish.finish_time()
                    list_in_cloud.append(job_finish)
                    break
                # update every jobs of departure network time
                departure_time = master_clock + network_latency[network_processor.index]
                network_processor.modify_network_time(departure_time)
                # departure time list is used to find the min departure time
                departure_time_list.append(departure_time)
                # network latency jobs list is used to send the jobs to the cloud
                network_latency_jobs.append(network_processor)

                # find the min departure time
                if departure_time < next_departure_time:
                    next_departure_time = departure_time
                # send all jobs whose departure time is smaller than master clock
                while master_clock >= next_departure_time and departure_time_list:
                    for j in range(len(network_latency_jobs)):
                        if network_latency_jobs[j].networkDeTime == next_departure_time:
                            list_in_cloud.append(network_latency_jobs[j])
                            del network_latency_jobs[j]
                            del departure_time_list[j]
                            break
                    next_departure_time = min(departure_time_list)
            else:
                pass


class ProcessorSharingInCloud(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        global time_end
        global list_in_cloud
        cloud_last_time = 0
        cloud_next_departure_time = float('inf')  # initial value is infinite
        cloud_job_list = []
        cloud_index = 0
        master_clock = 0
        print("Processor sharing in cloud...\n")
        while True:
            # waiting for jobs departure network and arriving in cloud
            if list_in_cloud:
                cloud_processor = list_in_cloud.pop(0)
                # Update the next arrival time
                next_arrival_time = cloud_processor.networkDeTime
                if master_clock >= time_end or cloud_processor.finish == 1:
                    # some jobs don't departure so clear the jobs list whose jobs are sent by time end
                    while cloud_job_list and cloud_next_departure_time < time_end:
                        master_clock = cloud_next_departure_time
                        # update the residual service time of each job when one job departure
                        update_service_time(master_clock, cloud_last_time, cloud_job_list)

                        # delete the finished job
                        job_departure_cloud = del_job(cloud_index, cloud_job_list)
                        job_departure_cloud.modify_response_time(master_clock - job_departure_cloud.arvTime)
                        job_departure_cloud.modify_cloud_time(master_clock)

                        # update the next departure time by comparing the least value
                        cloud_next_departure_time, cloud_index = update_next_departure_time(master_clock,
                                                                                            cloud_job_list)
                        cloud_last_time = master_clock

                    break
                while True:
                    if next_arrival_time < cloud_next_departure_time:
                        master_clock = next_arrival_time
                        # update the residual service time of each job when one job arrival
                        update_service_time(master_clock, cloud_last_time, cloud_job_list)
                        # add jobs to job list, since the new jobs are not served,
                        # the residual service time is initial service time
                        cloud_job_list.append(cloud_processor)
                        # update the next departure time by comparing the least value
                        cloud_next_departure_time, cloud_index = update_next_departure_time(master_clock,
                                                                                            cloud_job_list)
                        cloud_last_time = master_clock
                        break

                    else:                                          # next event is departure
                        if cloud_next_departure_time > time_end:
                            break
                        # Master clock equal to upcoming departure time
                        master_clock = cloud_next_departure_time
                        # update the residual service time of each job when one job departure
                        update_service_time(master_clock, cloud_last_time, cloud_job_list)

                        # delete the finished job and update the record we need
                        job_departure_cloud = del_job(cloud_index, cloud_job_list)
                        job_departure_cloud.modify_response_time(master_clock - job_departure_cloud.arvTime)
                        job_departure_cloud.modify_cloud_time(master_clock)

                        # update the next departure time by comparing the least value
                        cloud_next_departure_time, cloud_index = update_next_departure_time(master_clock,
                                                                                            cloud_job_list)
                        cloud_last_time = master_clock
                        # if the jobs queue is vacant, then set the next departure time equal to infinite
                        if len(cloud_job_list) == 0:
                            cloud_next_departure_time = float('inf')
            else:
                pass


# if the initial server list is larger than time limit in fog, update the server in fog list equal to fog time limit
# and the residual time in server list which is the same as server list in cloud;
# if it's no larger than time limit, just record the server time in server in fog list and update the server list in
# cloud equal to 0.
def simulation(mode, arrival_list, server_list, network_latency_list, time,
                             para_fogTimeLimit, para_fogTimeToCloudTime):
    global arrival_time_list
    global server_time_list
    global network_latency
    global time_end
    global list_in_network
    global list_in_cloud
    global record_list
    global fogTimeLimit
    global fogTimeToCloudTime
    global server_in_fog
    global server_in_cloud
    record_list = []
    arrival_time_list = arrival_list
    server_time_list = server_list
    network_latency = network_latency_list
    fogTimeLimit = para_fogTimeLimit
    fogTimeToCloudTime = para_fogTimeToCloudTime
    if mode == 'trace':
        time_end = float('inf')
    else:
        time_end = time

    length = len(server_time_list)
    server_in_fog = [0 for _ in range(length)]
    server_in_cloud = [0 for _ in range(length)]
    for i in range(length):
        if server_time_list[i] <= fogTimeLimit:
            server_in_fog[i] = server_time_list[i]
            server_in_cloud[i] = 0
            network_latency[i] = 0
        else:
            server_residual = fogTimeToCloudTime*(server_time_list[i] - fogTimeLimit)
            server_in_fog[i] = fogTimeLimit
            server_in_cloud[i] = server_residual

    threads = []
    fog_thread = ProcessorSharingInFog()
    network_thread = NetworkLatency()
    cloud_thread = ProcessorSharingInCloud()
    fog_thread.start()
    network_thread.start()
    cloud_thread.start()
    threads.append(fog_thread)
    threads.append(network_thread)
    threads.append(cloud_thread)
    for t in threads:
        t.join()
    return record_list
