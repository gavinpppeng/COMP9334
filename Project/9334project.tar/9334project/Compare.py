# A support material to compare the systems which have different fogTimeLimit with different seed.
# And calculate the confidence interval with transient removal
# It must be in the same directory as Simulation.py
import Simulation
import numpy as np
from math import sqrt, pow
import random
arrival_time_list = []
server_time_list = []
network_latency = []
response_time = 0
mean_response_time_list = []


# The random mode: generating  the random numbers
def random_mode(Lambda, alpha1, alpha2, beta, v1, v2, para_seed):
    global time_end
    global arrival_time_list
    global network_latency
    global server_time_list
    random.seed(para_seed)
    np.random.seed(para_seed)
    nb_of_jobs = 0
    arrival_time = 0
    network_late = 0

    # ########## generating the arrival times ########################
    while arrival_time < time_end:
        random_arrival = random.expovariate(Lambda)
        if random_arrival == 0:   # since the uniform distribution is in (0, 1) and that is used to get the exponential distribution
            continue
        arrival_time = arrival_time + random_arrival
        if arrival_time > time_end:
            break
        arrival_time_list.append(arrival_time)
        nb_of_jobs += 1

    # ######### generating the service time #########################
    gama = (1 - beta) / ((alpha2 ** (1 - beta)) - (alpha1 ** (1 - beta)))  # calculate the gama
    for _ in range(nb_of_jobs):
        prob = np.random.uniform(0, 1)
        while prob == 0:       # since the uniform distribution is in (0, 1)
            prob = np.random.uniform(0, 1)
        # from report.pdf, we can get the service time
        service_time = (prob*(1-beta)/gama + alpha1**(1-beta)) ** (1/(1-beta))
        server_time_list.append(service_time)

    # ######### generating the network latency ######################
    for _ in range(nb_of_jobs):
        network_late = np.random.uniform(v1,v2)
        while network_late == v1:       # since the distribution is in the open interval (v1,v2)
            network_late = np.random.uniform(v1,v2)
        network_latency.append(network_late)

mode = 'random'
Lambda = 9.72
alpha1 = 0.01
alpha2 = 0.4
beta = 0.86
v1 = 1.2
v2 = 1.47
fogTimeLimit = 0.11
fogTimeToCloudTime = 0.6
time_end = 1500
response_file = 'fogTimeLimit_' + str(fogTimeLimit) + '.txt'
x = 0
fr = open(response_file, 'w')

# put the seed equal from 0 to 60
for various_seed in range(61):
    random_mode(Lambda, alpha1, alpha2, beta, v1, v2, various_seed)
    record_list = Simulation.simulation(mode, arrival_time_list, server_time_list, network_latency, time_end,
                                        fogTimeLimit, fogTimeToCloudTime)
    print(f'fog time limit is {fogTimeLimit}')
    print(f'seed is {various_seed}')
    # transient removal
    count = len(record_list)-4000
    without_count = len(record_list)
    
    for k in range(4000, len(record_list)):
        # exclude the response time equal 0
        if record_list[k].responseTime == 0:
            count -= 1
        response_time = record_list[k].responseTime + response_time

    mean_response_time_list.append(response_time/count)
    fr.write(f'{response_time/count}\n')
    print(f'The mean response time with transient removal is {response_time/count}')
    arrival_time_list = []
    server_time_list = []
    network_latency = []
    record_list = []
    response_time = 0

# Computing the confidence interval
mean_T = sum(mean_response_time_list) / len(mean_response_time_list)
print(f'mean time is {mean_T}')
for k in range(len(mean_response_time_list)):
    x = x + (mean_T - mean_response_time_list[k])**2
y = x/(len(mean_response_time_list)-1)
standard_deviation = sqrt(y)
print(f'standard is {standard_deviation}')
# check the t_distribution_table, probability = 95%, so the p = 0.975 and the n = 60
t = 2
lower_bound = mean_T - t * (standard_deviation/sqrt(len(mean_response_time_list)))
upper_bound = mean_T + t * (standard_deviation/sqrt(len(mean_response_time_list)))
CI_file = 'confidence_interval_' + str(fogTimeLimit) + '.txt'
fc = open(CI_file, 'w')
fc.write(f'{lower_bound}\t{upper_bound}')
print(f'Confidence interval is [{lower_bound},{upper_bound}]')
