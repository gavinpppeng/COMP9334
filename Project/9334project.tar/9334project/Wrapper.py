# A port to test the 9334 project
import Simulation
import numpy as np
import random
from matplotlib import pyplot as plt
arrival_time_list = []
server_time_list = []
network_latency = []
time_end = float('inf')
fogTimeLimit = 0
fogTimeToCloudTime = 0
seed = 1
response_time = 0
response_time_with_removal = 0
count = 0
count_removal = 0


# The random mode: generating  the random numbers
def random_mode(Lambda, alpha1, alpha2, beta, v1, v2):
    global time_end
    global arrival_time_list
    global network_latency
    global server_time_list
    global seed
    random.seed(seed)
    np.random.seed(seed)
    nb_of_jobs = 0
    arrival_time = 0
    network_late = 0

    # ########## generating the arrival times ########################
    while arrival_time < time_end:
        random_arrival = random.expovariate(Lambda)
        if random_arrival == 0:   # since the uniform distribution is in (0, 1) and that is used to get the exponential distribution
            continue
        arrival_time = arrival_time + random_arrival
        if arrival_time > time_end:
            break
        arrival_time_list.append(arrival_time)
        nb_of_jobs += 1

    # ######### generating the service time #########################
    gama = (1 - beta) / ((alpha2 ** (1 - beta)) - (alpha1 ** (1 - beta)))  # calculate the gama
    for _ in range(nb_of_jobs):
        prob = np.random.uniform(0, 1)
        while prob == 0:       # since the uniform distribution is in (0, 1)
            prob = np.random.uniform(0, 1)
        # from report.pdf, we can get the service time
        service_time = (prob*(1-beta)/gama + alpha1**(1-beta)) ** (1/(1-beta))
        server_time_list.append(service_time)

    # ######### generating the network latency ######################
    for _ in range(nb_of_jobs):
        network_late = np.random.uniform(v1,v2)
        while network_late == v1:           # since the distribution is in the open interval (v1,v2)
            network_late = np.random.uniform(v1,v2)
        network_latency.append(network_late)


# filename = input("Please input the path of num_tests.txt")
filename = "num_tests.txt"
file = open(filename)
nb_of_tests = int(file.read())

for i in range(1, nb_of_tests+1):
    # read the mode file to get the mode of simulation
    mode_file = "mode_"+str(i) + ".txt"
    with open(mode_file, 'r') as fmode:
        mode = fmode.read()
    # get the para file
    para_file = "para_"+str(i) + ".txt"
    # get the arrival file
    arrival_file = "arrival_"+str(i)+".txt"
    # get the service file
    service_file = "service_"+str(i)+".txt"
    # get the network file
    network_file = "network_"+str(i)+".txt"

    # trace mode
    if mode == "trace":
        print(f'############# Test {i} Trace mode ################################')
        # no need time end
        time_end = float('inf')
        # open para*.txt
        with open(para_file, 'r') as pfile:
            fogTimeLimit = float(pfile.readline())
            fogTimeToCloudTime = float(pfile.readline())
        # arrival time list
        with open(arrival_file, 'r') as afile:
            while True:
                lines = afile.readline()
                if not lines:
                    break
                arrival_time_list.append(float(lines))
        # server time list
        with open(service_file, 'r') as sfile:
            while True:
                slines = sfile.readline()
                if not slines:
                    break
                server_time_list.append(float(slines))
        # network latency list
        with open(network_file, 'r') as nfile:
            while True:
                nlines = nfile.readline()
                if not nlines:
                    break
                network_latency.append(float(nlines))

    elif mode == "random":
        print(f'############# Test {i} Random mode ################################')
        # open para*.txt
        with open(para_file, 'r') as pfile:
            fogTimeLimit = float(pfile.readline())
            fogTimeToCloudTime = float(pfile.readline())
            time_end = float(pfile.readline())
        # arrival time list
        with open(arrival_file, 'r') as afile:
            Lambda = float(afile.readline())
        # server time list
        with open(service_file, 'r') as sfile:
            alpha1 = float(sfile.readline())
            alpha2 = float(sfile.readline())
            beta = float(sfile.readline())
        # network latency list
        with open(network_file, 'r') as nfile:
            v1 = float(nfile.readline())
            v2 = float(nfile.readline())
        random_mode(Lambda, alpha1, alpha2, beta, v1, v2)
    record_list = Simulation.simulation(mode, arrival_time_list, server_time_list, network_latency, time_end,
                                        fogTimeLimit, fogTimeToCloudTime)
    print(f'fog time limit is {fogTimeLimit}')
    # exclude the response time equal 0
    count = len(record_list)
    count_removal = len(record_list)
    # open the file
    fog_file = 'fog_dep_' + str(i) + '.txt'
    ff = open(fog_file, 'w')
    net_file = 'net_dep_' + str(i) + '.txt'
    fn = open(net_file, 'w')
    cloud_file = 'cloud_dep_' + str(i) + '.txt'
    fc = open(cloud_file, 'w')
    response_file = 'mrt_' + str(i) + '.txt'
    fr = open(response_file, 'w')


    for k in range(len(record_list)):
        # print(f'index is {record_list[k].index}')
        # write in the file
        if record_list[k].fogDeTime !=0:
            ff.write(f'{record_list[k].arvTime:.4f}\t{record_list[k].fogDeTime:.4f}\n')
        # Some responsetime not equal to 0, maybe departure directly from fog, thus we need to add more constraint
        if record_list[k].networkDeTime != 0 and record_list[k].networkDeTime < time_end:
            fn.write(f'{record_list[k].arvTime:.4f}\t{record_list[k].networkDeTime:.4f}\n')
        if record_list[k].responseTime != 0 and record_list[k].networkDeTime != 0 \
            and record_list[k].networkDeTime < time_end:       
            fc.write(f'{record_list[k].arvTime:.4f}\t{record_list[k].cloudDeTime:.4f}\n')
        if record_list[k].responseTime == 0:
            count -= 1
        response_time = record_list[k].responseTime + response_time

        # mean response time with tranisent removal
        if k >= 4000:
            if record_list[k].responseTime == 0:
                count_removal -= 1
            response_time_with_removal = record_list[k].responseTime + response_time_with_removal


    fr.write(f'{response_time/count:.4f}')
    print(f'The mean response time is {response_time/count}')
    print(f'The nb of jobs is {count}')

    print(f'The mean response time with removal is {response_time_with_removal/(count_removal-4000)}')


    if mode == 'random':
        response_time_list = []
        mean_response_time = []
        mean_response_time_removal = []
        for k in range(len(record_list)):
            if record_list[k].responseTime != 0:
                response_time_list.append(record_list[k].responseTime)
        jobs = [m for m in range(len(response_time_list))]
        for o in range(1, len(response_time_list)+1):
            mean_response_time.append(sum(response_time_list[:o])/o)
            #print(sum(response_time_list[:o])/o)
        plt.title("9334 Project: Fog/Cloud Computing")
        plt.xlabel(f'Number of jobs, fogTimeLimit = {fogTimeLimit}, time_end = {time_end}')
        plt.ylabel("Mean response time")
        plt.plot(np.array(jobs), np.array(mean_response_time))
        plt.axvline(4000, linestyle="dotted", linewidth=4, color='r')
        plt.show()
    arrival_time_list = []
    server_time_list = []
    network_latency = []
    record_list = []
    response_time = 0
    response_time_with_removal = 0
    count = 0
