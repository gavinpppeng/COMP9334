%% 9334 Assignment1 3(c)
% 
% For this problem, I have chosen to use the first 5 equations from 3(b)
% with sum( probabilities ) = 1 
% We put the linear equations in standard form A x = b
% where x is the unknown vector
% 
A = [ 1/150  -1/90  -1/60   0   0   0
     -1/150  29/1800   0  -1/60  0   0
     0   0   13/600   -1/90  0  0
      0  -1/200   -1/200   7/225   -1/36   0
      0  0  0   -1/300   53/1800   -1/36
      1   1   1   1   1   1];
b = [0 0 0 0 0 1]';
x = A\b
