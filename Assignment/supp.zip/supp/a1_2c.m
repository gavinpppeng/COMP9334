%% 9334 Assignment1 2(c)
% Version: MATLAB R2018b
%
% We can use this to determine the probability when the mean response time
% of the server farm is the smallest possible.
% The plot will be different if the MATLAB version is old, and the
% probability is between 0 and 1, so we just need to observe this interval.
f=@(p) p/(10-20*p)+(1-p)/(15-(1-p)*20);
fplot(f,[0,1]);
%
% Since the response time must be greater than 0 and we will find  the
% response time has smallest value when it is greater than 0.
ylim([0 5])
%
% We can use this to get the probability that makes the mean response time
% get the smallest value. And from above plot, we know the smallest value
% is between 0.25 and 0.5, thus, we can get the probability values 
% when the mean response time get the smallest value.
pmin = fminbnd(f,0.25,0.5)


